package testRunner;


	
	import org.junit.runner.RunWith;
	import io.cucumber.junit.Cucumber;
	import io.cucumber.junit.CucumberOptions;
	public class Project_1_CRM 
	 {
	    @RunWith(Cucumber.class)
		@CucumberOptions(
		    features = "C:/Users/surbh/eclipse-workspace/cucu_Pro/src/test/java/features/Project_suite_CRM.feature",
		    glue = {"StepDefinations"},
		    tags = "@Counting_Dashlets",
		    
		    strict = true,
		    plugin = {"html: test-reports"},
		    monochrome = true
		)

		public class Activity_HRM_1 {
		    //empty
		}
	}


