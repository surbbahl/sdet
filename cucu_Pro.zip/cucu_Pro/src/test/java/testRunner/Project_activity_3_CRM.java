package testRunner;
import org.junit.runner.RunWith;
	import io.cucumber.junit.Cucumber;
	import io.cucumber.junit.CucumberOptions;
	
	    @RunWith(Cucumber.class)
		@CucumberOptions(
		    features = "C:/Users/surbh/eclipse-workspace/cucu_Pro/src/test/java/features/Project_CRM_activity_3.feature",
		    glue = {"StepDefination"},
		    tags = "@Meeting_4",
		    
		    strict = true,
		    plugin = {"html: test-reports"},
		    monochrome = true)
	public class Project_activity_3_CRM {
		    //empty
		}
	


