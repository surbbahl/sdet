package testRunner;
import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
public class Project_1_HRM {
	
	

	@RunWith(Cucumber.class)
	@CucumberOptions(
	    features = "C:/Users/surbh/eclipse-workspace/cucu_Pro/src/test/java/features/Project_HRM_1.feature",
	    glue = {"StepDefinations"},
	    tags = "@HRM_1",
	    
	    strict = true,
	    plugin = {"html: test-reports"},
	    monochrome = true
	)

	public class Activity_HRM_1 {
	    //empty
	}
}
