package testRunner;


	
	import org.junit.runner.RunWith;
	import io.cucumber.junit.Cucumber;
	import io.cucumber.junit.CucumberOptions;
	public class Activity_2_CRM 
	 {
	    @RunWith(Cucumber.class)
		@CucumberOptions(
		    features = "C:/Users/surbh/eclipse-workspace/cucu_Pro/src/test/java/features/Project_CRM_activity_2.feature",
		    glue = {"StepDefinations"},
		    tags = "@Leads",
		    
		    strict = true,
		    plugin = {"html: test-reports"},
		    monochrome = true
		)

		public class Activity_CRM_2 {
		    //empty
		}
	}


