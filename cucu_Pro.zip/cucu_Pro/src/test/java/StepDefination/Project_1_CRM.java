package StepDefination;
import java.io.File;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Project_1_CRM {
	WebDriver driver;
	WebDriverWait wait;
	@Before()
	public void before()
	{
	
	driver=new FirefoxDriver();
    wait = new WebDriverWait(driver, 15);
	
	}
	@Given("^Open the URL$")
    public void userIsOnJobPortal() throws Throwable {
        driver.navigate().to("http://alchemy.hguy.co/crm/");
	}
	
	@When("^Login using username and password and click on login$")
	public void User_logins() throws Throwable{
		driver.findElement(By.id("user_name")).sendKeys("admin");
        driver.findElement(By.id("username_password")).sendKeys("pa$$w0rd");
        driver.findElement(By.id("bigbutton")).click();
        int count=0;
        List<WebElement> lt = driver.findElements(By.xpath("//li[contains(@class,'topnav')]"));
        for (WebElement l :lt) {
        	count=count+1;
        	System.out.println("Names of Dash lets "+l.getText());
        }
		System.out.println("Count="+count);
	}
	@Then("User closes the browser")
		public void user_closes() 
		{
		driver.close();
		}
	

}
