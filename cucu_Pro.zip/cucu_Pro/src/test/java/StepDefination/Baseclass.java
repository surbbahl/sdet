package StepDefination;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.Given;

public class Baseclass {
	WebDriver driver;
	WebDriverWait wait;
	{
	driver=new FirefoxDriver();
    wait = new WebDriverWait(driver, 15);
	

}
}

