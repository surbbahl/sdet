package StepDefination;
import java.io.File;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Project_activity_3_CRM {
	WebDriver driver;
	WebDriverWait wait;
	
			@Before()
			public void before_C()
			{

		     driver=new FirefoxDriver();
		     wait = new WebDriverWait(driver, 15);
			}
			@Given("Open the URL for Meeting")
			
		    public void userIsOnJobPortal_meetings() throws Throwable
			{
		        driver.navigate().to("http://alchemy.hguy.co/crm/");
		    }
			@When("^Login in ProjectURL with username and password for meeting$")
			public void UserLogins_meeting() throws Throwable
			{
				driver.findElement(By.id("user_name")).sendKeys("admin");
		        driver.findElement(By.id("username_password")).sendKeys("pa$$w0rd");
		        driver.findElement(By.id("bigbutton")).click();
			}
			@Then("^Select Meeting and add people into it$")
			public void Meeting_creation() throws Throwable
			{
				WebElement ele= driver.findElement(By.id("grouptab_3"));
				Actions action1=new Actions(driver);
				action1.moveToElement(ele).moveToElement(driver.findElement(By.xpath("//li//a[@id='moduleTab_9_Meetings']"))).click().build().perform();
				Thread.sleep(10000);
				driver.findElement(By.xpath("//div[@id='actionMenuSidebar']//ul//li[@class='actionmenulinks']//a[@data-action-name='Schedule_Meeting']//div[@class='side-bar-action-icon']//span[@class='suitepicon suitepicon-action-schedule-meeting']")).click();
				Thread.sleep(10000);
				driver.findElement(By.xpath("//input[@id='name']")).sendKeys("Surbhi_meeting");
				//driver.findElement(By.xpath("//li[@id='tab-actions']")).click();
				//driver.findElement(By.xpath("//dropdown-menu//li//input[@id='edit_button']")).click();
				//driver.findElement(By.xpath("//button[@id='btn_assigned_user_name']")).click();
				
				/*driver.findElement(By.xpath("//li[@id='tab-actions']//a[@class='dropdown-toggle']//span[@class='suitepicon suitepicon-action-caret']")).click();
				//String st=driver.getWindowHandle();
				driver.switchTo().window(st);
				for (String st1:driver.getWindowHandles())
				{
					driver.switchTo().window(st1);
				}
				
				driver.findElement(By.xpath("//input[@id='first_name_advanced']")).sendKeys("Surbhi");*/
				JavascriptExecutor js = (JavascriptExecutor)driver;
			    js.executeScript("window.scrollBy(0,3000)");
				driver.findElement(By.xpath("//input[@id='search_first_name']")).sendKeys("sarah");
				driver.findElement(By.xpath("//input[@id='invitees_search']")).click();
				Thread.sleep(10000);
				driver.findElement(By.xpath("//input[@id='invitees_add_1']")).click();
				driver.findElement(By.xpath("//input[@id='SAVE_HEADER']")).click();
			}
			@Then("Click on All and add products")
			public void all_products() throws Throwable
			{
			Thread.sleep(10000);
			driver.findElement(By.xpath("//li[@class='topnav all']//span[@class='notCurrentTab']//a[@id='grouptab_5']")).click();
			Thread.sleep(10000);
			JavascriptExecutor js = (JavascriptExecutor)driver;
		    js.executeScript("window.scrollBy(0,5000)");
			driver.findElement(By.linkText("Products")).click();
			
			
			}
			
}
