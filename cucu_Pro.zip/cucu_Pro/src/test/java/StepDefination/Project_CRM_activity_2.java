package StepDefination;
import java.io.File;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;

public class Project_CRM_activity_2 extends Baseclass {
	WebDriver driver;
	WebDriverWait wait;
	
			@Before()
			public void before_C()
			{

		     driver=new FirefoxDriver();
		     wait = new WebDriverWait(driver, 15);
			}
			@Given("^Open the URL for leads$")
		    public void userIsOnJobPortal_Leads() throws Throwable {
		        driver.navigate().to("http://alchemy.hguy.co/crm/");
		    }
			@When("^Login using username and password and click on login for leads$")
			public void User_logins_Leads() throws Throwable{
				driver.findElement(By.id("user_name")).sendKeys("admin");
		        driver.findElement(By.id("username_password")).sendKeys("pa$$w0rd");
		        driver.findElement(By.id("bigbutton")).click();
			}
			@SuppressWarnings("deprecation")
			@Then("User click on Leeds and select Sales")
			public void lead_sales() throws Throwable
			{	
				
				Thread.sleep(1000);
				Actions action1=new Actions(driver);
				WebElement sales_1=driver.findElement(By.xpath("//a[text()='Sales']"));
				Thread.sleep(10000);
				action1.click(sales_1);
				action1.moveToElement(sales_1).moveToElement(driver.findElement(By.xpath("//*[@class='dropdown-menu']//li//a[@id='moduleTab_9_Leads']"))).click().build().perform();
				Thread.sleep(10000);
				driver.findElement(By.xpath("//div[contains(@class,'sidebar')]//div[@id='actionMenuSidebar']//ul//li[1]//a//div[contains(@class,'icon')]//span[contains(@class,'create')]")).click();
				Thread.sleep(10000);
				WebElement ele=driver.findElement(By.id("salutation"));
		    	Select select=new Select(ele);
		    	select.selectByIndex(1);
		    	driver.findElement(By.id("first_name")).sendKeys("surb4");
		    	driver.findElement(By.id("last_name")).sendKeys("Bajaj");
		    	driver.findElement(By.id("phone_mobile")).sendKeys("111111111");
		    	driver.findElement(By.id("SAVE")).click();
		    	Thread.sleep(1000);
		    	//driver.findElement(By.xpath("//input[@class='button' and @value='Save']")).click();
		    	String st =driver.findElement(By.xpath("//div[@id='recentlyViewedSidebar']//ul[@class='nav nav-pills nav-stacked']//div[1]//li[1]//a//span[2]")).getText();;
		    	System.out.println(st);
		    	Assert.assertEquals("Mr. surb4 Bajaj", st);
		    	
			}
			@Then("Close the browser for leads")
			public void close_browser() throws Throwable
			{
				driver.close();
			}
}



