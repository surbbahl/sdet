package StepDefination;
import java.io.File;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Project_1_HRM {
	WebDriver driver;
	WebDriverWait wait;
	
			@Before()
			public void before_C()
			{

		     driver=new FirefoxDriver();
		     wait = new WebDriverWait(driver, 15);
			}
		    
		    @Given("User is on job Portal")
		    public void userIsOnJobPortal() throws Throwable {
		        //Create a new instance of the Firefox driver
		        
		        
		                
		        //Open the browser
		        driver.navigate().to("http://alchemy.hguy.co/orangehrm");
		    }
		   
		    @When("^User enters Username and password$")
		    public void userEntersPassword() throws Throwable {
		        driver.findElement(By.id("txtUsername")).sendKeys("orange");
		        driver.findElement(By.id("txtPassword")).sendKeys("orangepassword123");
		        //driver.findElement(By.id("btnLogin")).click();
		        
		    }
		    
		        
		        
		   @Then("^Click on Login$")
		    public void clickOnLogin() throws Throwable {
		        driver.findElement(By.id("btnLogin")).click();
		    }
		   @When("User is on home Portal")
		   public void homepage() throws Throwable
		   {
			   System.out.println("Mehere ");
		   }

		    @When("^Opening the Recuritment Portal and click on vacancy$")
		    public void Open_Rec() throws Throwable {
			   Thread.sleep(100);
		    	driver.findElement(By.id("menu_recruitment_viewRecruitmentModule")).click();
		    	driver.findElement(By.id("menu_recruitment_viewJobVacancy")).click();
		    	driver.findElement(By.id("btnAdd")).click();
		    	
		    	WebElement ele=driver.findElement(By.id("addJobVacancy_jobTitle"));
		    	Select select=new Select(ele);
		    	select.selectByIndex(1);
		    	
		    	driver.findElement(By.id("addJobVacancy_name")).sendKeys("Surbhi123");
		    	driver.findElement(By.id("addJobVacancy_hiringManager")).sendKeys("ATest123 Automation");
		    	driver.findElement(By.id("addJobVacancy_noOfPositions")).sendKeys("2");
		    	driver.findElement(By.id("btnSave")).click();
		    	

		    }
		   @Then("User click on Candidates and click add")
		   public void Enter_candidate() throws Throwable
		   {
			   driver.findElement(By.id("menu_recruitment_viewCandidates")).click();
			   driver.findElement(By.id("btnAdd")).click();
			   
		    	
			   }
		   @Then("Enter user details")
		   public void enter_details()
		   {
			   driver.findElement(By.id("addCandidate_firstName")).sendKeys("Surbhi");
			   driver.findElement(By.id("addCandidate_lastName")).sendKeys("Bahl");
			   driver.findElement(By.id("addCandidate_email")).sendKeys("sur.bahl@g.com");
			   WebElement ele=driver.findElement(By.id("addCandidate_vacancy"));
		    	Select select=new Select(ele);
		    	select.selectByIndex(4);
		    	WebElement wb=driver.findElement(By.id("addCandidate_resume"));
		    	File file=new File("C:/Users/surbh/OneDrive/Desktop/CV.docx");
		    	wb.sendKeys(file.getAbsolutePath());
		       driver.findElement(By.id("btnSave")).click();
		       List<WebElement> secondlist = driver.findElements(By.xpath("//table[@id='resultTable']/tbody/tr[2]/td[2]"));
		       for (WebElement cellvalue:secondlist)
		       {
		    	   System.out.println(cellvalue.getText());
		    	   
		       }
		       
		       
		       
		   }
		   @When("^User clicks on PIM and add details with \"(.*)\" and \"(.*)\" and \"(.*)\"$")
		   public void Enter_PIM_details(String firstName , String lastName,String user_name)
		   {
			   driver.findElement(By.id("menu_pim_viewPimModule")).click();
		       driver.findElement(By.id("btnAdd")).click();
		       driver.findElement(By.id("firstName")).sendKeys(firstName);
		       driver.findElement(By.id("lastName")).sendKeys(lastName);
		       driver.findElement(By.id("employeeId")).clear();
		       driver.findElement(By.id("employeeId")).sendKeys("123456");
		       driver.findElement(By.id("chkLogin")).click();
		       
		       driver.findElement(By.id("user_name")).sendKeys(user_name);
		       driver.findElement(By.id("btnSave")).click();
		   }
		   @When("User Enter on Recruitment")
		   public void Enter_Recruitment()
		   {
			driver.findElement(By.id("menu_recruitment_viewRecruitmentModule")).click();
	    	driver.findElement(By.id("menu_recruitment_viewJobVacancy")).click();
	    	driver.findElement(By.id("btnAdd")).click();
		   }
		   @When("^User Enter vacancy example with \"(.*)\" and \"(.*)\" and \"(.*)\"$")
		   								
		   public void Enter_vacancy_details(int JobTitle ,String VacancyName, String HiringManager)
		   {
			    
		    	
		    	WebElement ele=driver.findElement(By.id("addJobVacancy_jobTitle"));
		    	Select select=new Select(ele);
		    	select.selectByIndex(JobTitle);
		    	
		    	driver.findElement(By.id("addJobVacancy_name")).sendKeys(VacancyName);
		    	driver.findElement(By.id("addJobVacancy_hiringManager")).sendKeys(HiringManager);
		    	driver.findElement(By.id("addJobVacancy_noOfPositions")).sendKeys("2");
		    	driver.findElement(By.id("btnSave")).click();
			   
		   }
		   
		   
		}



