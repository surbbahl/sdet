package StepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;

public class Job_Activity_1 {
	WebDriver driver;
	WebDriverWait wait;
	
			@Before()
			
			public void before_C()
			{

		     driver=new FirefoxDriver();
		     wait = new WebDriverWait(driver, 15);
		     
		    
			}
			@Given("^Open the URL for Job$")
			public void userIsOnJobPortal() throws Throwable
			{
		        driver.navigate().to("https://alchemy.hguy.co/jobs/wp-admin");
		    }
			@Given("^Open the URL for Job site$")
			public void useropendJobPortal()
			{
				driver.navigate().to("https://alchemy.hguy.co/jobs/");
			}
           
			@When("^Login using username and password and click on login for jobs$")
			public void User_logins_job_Portal() throws Throwable
			{
				driver.findElement(By.id("user_login")).sendKeys("root");
		        driver.findElement(By.id("user_pass")).sendKeys("pa$$w0rd");
		        driver.findElement(By.id("wp-submit")).click();
		        driver.findElement(By.linkText("Users")).click();
		        driver.findElement(By.linkText("Add New")).click();
		        driver.findElement(By.id("user_login")).sendKeys("Ankush_Jethi16");
		        driver.findElement(By.id("email")).sendKeys("ank15@xyz.com");
		        driver.findElement(By.id("first_name")).sendKeys("s");
		        driver.findElement(By.id("last_name")).sendKeys("B");
		        driver.findElement(By.xpath("//table[contains(@class,'table')]//tbody//tr[6]//td[1]//button[contains(@class,'generate')]")).click();
		        //WebElement scroll=driver.findElement(By.id("createusersub"));
		        JavascriptExecutor js = (JavascriptExecutor)driver;
		        js.executeScript("window.scrollBy(0,1000)");
		        Thread.sleep(1000);
		        
		        driver.findElement(By.id("createusersub")).click();
		        driver.findElement(By.id("user-search-input")).sendKeys("Ankush_Jethi16");
			}
			
			@Then ("^Search for the user$")
			public void user_check() throws Throwable
			{
				driver.findElement(By.id("search-submit")).click();
		        String st=driver.findElement(By.linkText("Ankush_Jethi16")).getText();
		        System.out.println(st);
		        Assert.assertEquals("Ankush_Jethi15", st);
			}
			@Then("^click on Job$")
	           public void user_click_nJob() throws Throwable
	           {
	        	   driver.findElement(By.linkText("Jobs")).click();
	        	  
	         }
			@Then("^Search the job$")
			public void user_serach_job() throws Throwable
			{
				 driver.findElement(By.xpath("//input[@id='job_type_freelance']")).click();
	        	   
	        	   driver.findElement(By.xpath("//input[@id='job_type_internship']")).click();
	        	   
	        	   driver.findElement(By.xpath("//input[@id='job_type_part-time']")).click();
	        	   
	        	   driver.findElement(By.xpath("//input[@id='job_type_temporary']")).click();
	        	   
	        	  // String st =driver.findElement(By.xpath("//div[@class='showing_jobs wp-job-manager-showing-all']//span")).getText();
	        	  // System.out.println(st);
	        	   
	        	   driver.findElement(By.id("search_keywords")).sendKeys("IBM");
	        	   driver.findElement(By.id("search_location")).sendKeys("Delhi");
	        	   driver.findElement(By.xpath("//div[@class='search_submit']//input")).click();
	        	   Thread.sleep(1000);
	        	   driver.findElement(By.xpath("//ul[@class='job_listings']//li[contains(@class,'2459')]")).click();
	        	   
			}
			@Then("^apply for job$")
			public void apply_job() throws Throwable
			
			{   
				Thread.sleep(500);
				driver.findElement(By.xpath("//div[contains(@class,'job_application')]//input[contains(@class,'button')]")).click();
			}
			@Then("^Click for Posting job$")
			public void click_for_posting_job() throws Throwable
			{
				driver.findElement(By.linkText("Post a Job")).click();
			}
			@Then("^fill the details and submit the job$")
			public void fill_the_details() throws Throwable
			{
				driver.findElement(By.xpath("//input[@id='create_account_email']")).sendKeys("abc56@xyz.com");
				driver.findElement(By.id("job_title")).sendKeys("Java Developer surbhi1");
				WebElement wt=driver.findElement(By.id("job_type"));
				Select sl=new Select(wt);
				sl.selectByIndex(1);
				driver.findElement(By.id("company_name")).sendKeys("IBM");
				driver.findElement(By.id("job_location")).sendKeys("London");
				
				driver.findElement(By.id("application")).sendKeys("Abc86@gmail.com");
				driver.findElement(By.xpath("//iframe[@id='job_description_ifr']")).sendKeys("DDDDD");
				 JavascriptExecutor js = (JavascriptExecutor)driver;
			     js.executeScript("window.scrollBy(0,3000)");
			      Thread.sleep(1000);
				
				driver.findElement(By.xpath("//p//input[@class='button']")).click();
				Thread.sleep(1000);
				driver.findElement(By.xpath("//input[@id='job_preview_submit_button']")).click();
			}
			@Then("^Confirm if job is listed$")
			public void confirm_job() throws Throwable
			{
				driver.findElement(By.linkText("Jobs")).click();
				driver.findElement(By.id("search_keywords")).sendKeys("IBM");
	        	driver.findElement(By.id("search_location")).sendKeys("London");
	        	Thread.sleep(1000);
	        	String st=driver.findElement(By.xpath("//ul[@class='job_listings']//li[1]//a//div//h3")).getText();
	        	System.out.println(st);
	        	Assert.assertEquals("Java Developer surbhi1", st);
				
			}
			@Then("^fill_the_details_and_submit_the_job \"(.*)\" and \"(.*)\" and \"(.*)\" and \"(.*)\" and \"(.*)\" and \"(.*)\" and \"(.*)\"$")
			public void fill_details_with_examples(String Email,String job_title,String job_type1,String company_name,String job_location,String application, String Description) throws Throwable
			{
				driver.findElement(By.xpath("//input[@id='create_account_email']")).sendKeys(Email);
				driver.findElement(By.id("job_title")).sendKeys(job_title);
				WebElement wt=driver.findElement(By.id("job_type"));
				Select sl=new Select(wt);
				sl.selectByVisibleText(job_type1);
				driver.findElement(By.id("company_name")).sendKeys(company_name);
				driver.findElement(By.id("job_location")).sendKeys(job_location);
				
				
				driver.findElement(By.xpath("//iframe[@id='job_description_ifr']")).sendKeys(Description);
				 Thread.sleep(1000);
				driver.findElement(By.xpath("//div[@class='field required-field']//input[@id='application']")).sendKeys(application);
				 JavascriptExecutor js = (JavascriptExecutor)driver;
			     js.executeScript("window.scrollBy(0,3000)");
			    
			    
				driver.findElement(By.xpath("//p//input[@class='button']")).click();
				Thread.sleep(1000);
				driver.findElement(By.xpath("//input[@id='job_preview_submit_button']")).click();
				
			}
			@Then("^Check if job is created$")
			public void check_if_job_created_with_examples() throws Throwable
			{
				driver.findElement(By.linkText("click here")).click();
				Boolean bl=driver.findElement(By.xpath("//p[@class='name']")).isDisplayed();
				System.out.println(bl);
				
			}
			@Then("^Close the Browser$")
			
			public void user_close() throws Throwable
			{
				driver.close();
			}
			@Then("^Close the browser for job$")
			public void user_close_job() throws Throwable
			{
				driver.close();
			}
			
}

